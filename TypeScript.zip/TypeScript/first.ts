function greeter(person)
{
	return "Hello, "+person;
}

let user ="Akshata";
console.log(greeter(user))