function greeter(person) {
    return "Hello, " + person;
}
var user = "Akshata";
console.log(greeter(user));
