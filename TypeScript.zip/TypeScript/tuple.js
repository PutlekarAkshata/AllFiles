var empTuple = ["Rohit Sharma", 23, "Angular"];
console.log("Items: " + empTuple);
console.log("Length of Tuple items before push :" + empTuple.length);
empTuple.push(20001);
console.log("Length of Tuple items after push: " + empTuple.length);
console.log("Items: " + empTuple);
