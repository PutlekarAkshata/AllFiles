console.log("*********************");
var years1 = [1997, 1998, 1999, 2000];
for (var _i = 0, years1_1 = years1; _i < years1_1.length; _i++) {
    var i = years1_1[_i];
    console.log(i);
}
console.log("*********************");
var years2 = [1997, 1998, 1999, 2000];
for (var i in years2) {
    console.log(years2[i]);
}
console.log("*********************");
var years3 = [1997, 1998, 1999, 2000];
years3.forEach(function (yrs, i) {
    console.log(yrs);
});
