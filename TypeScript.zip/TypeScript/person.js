function greeter(person) {
    return "Hello " + person.firstname + " " + person.lastname;
}
var user = { firstname: "Akshata", lastname: "P" };
console.log(greeter(user));
