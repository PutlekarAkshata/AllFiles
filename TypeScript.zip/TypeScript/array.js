/**let arr:number[];
arr = [1,2,3,4,5];

console.log("Array[0]: "+arr[0]);
console.log("Array[1]: "+arr[1]);**/
var arrType;
var i;
arrType = [1, 2, 4, 3];
console.log(" Numeric type aaray: ");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
arrType = ["India", "America", "Africa"];
console.log("String type array ");
for (i = 0; i < arrType.length; i++) {
    console.log(arrType[i]);
}
