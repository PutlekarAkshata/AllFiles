function addition(num1,num2)
{
	return num1+num2;
}

var sum=addition("JavaTPoint",25);
console.log('Sum of numbers: '+sum);