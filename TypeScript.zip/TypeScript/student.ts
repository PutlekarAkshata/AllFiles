class Student
{
	fullname:string;
	constructor(public firstname:string, public middlename:string, public lastname:string)
	{
		this.fullname = firstname+ " "+middlename+" "+lastname;
	}
}
interface Person{
	firstname:string;
	lastname:string;
}

function greeter(person:Person)
{
	return "Hello "+person.firstname+" "+person.lastname;
}

let user = new Student("Akshata","A","Putlekar")

console.log(greeter(user))