package RefereneMethods;

public interface Sayable {
	void say();

}
