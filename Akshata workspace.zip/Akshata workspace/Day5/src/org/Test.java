package org;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		List <Product> pl=new ArrayList<Product>();
		Product p1=new Product(10,"Tv",36000);
		Product p2=new Product(11,"Refrigerator",16050);
		Product p3=new Product(12,"AC",9000);
		pl.add(p1);
		pl.add(p2);
		pl.add(p3);
		
		pl.add(new Product(13,"Mobile",32000));
		pl.add(new Product(14,"Washing Machine",7000));
		pl.add(new Product(15,"Phone",7000));
		
		/*for(Product p:pl){
			System.out.println("Prod.ID : "+p.getId()+" Name : "+p.getName()+" Price : "+p.getPrice());
		}*/
		List <Float> price=new ArrayList<Float>();
		List <String> name=new ArrayList<String>();
		/*for(Product s:pl){
			if(s.price<9000)
			{
				price.add(s.price);
				name.add(s.name);
			}
		}
		System.out.println(price);
		System.out.println(name);*/
		
		/*List <String> priceList = pl.stream()
							.filter(p -> p.price <=9000)
							.map(p->p.name)
							.collect(Collectors.toList());
		System.out.println(priceList);	*/	
		
		/*pl.stream().
			filter(p -> p.price == 7000)
			.forEach(p -> System.out.println(p.name));
		*/
		
		/*double totalprice=pl.stream()
				.collect(Collectors.summingDouble(p->p.price));
		System.out.println(totalprice);*/
		
		/*//Max price among products
		Product prodA = pl.stream()
				.max((prod1,prod2)->
				prod1.price>prod2.price?1:-1).get();
		System.out.println(prodA.price);
		
		
		//Min price among products
		Product prodB = pl.stream()
				.max((prod1,prod2)->
				prod1.price<prod2.price?1:-1).get();
		System.out.println(prodB.price);*/
		
		
		//count number of products under the given filter
		/*long count = pl.stream()
				.filter(prod->prod.price<10000)
				.count();
		System.out.println(count);*/
		
		/*Set<Float> prodList=pl.stream()
				.filter(p->p.price < 10000)
				.map(p->p.price)
				.collect(Collectors.toSet());
		System.out.println(prodList);*/
		
		/*Map<Integer,String> prodMap = pl.stream()
				.collect(Collectors.toMap(p->p.id,p->p.name));
		System.out.println(prodMap);*/
		
		List<Float> prodPrice =
				pl.stream()
				.map(Product::getPrice)
				.collect(Collectors.toList());
		System.out.println(prodPrice  );

	}

}
