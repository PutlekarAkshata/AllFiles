package FileInputOutput;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class FileOutput {

	public static void main(String[] args) {
		try{
			
			// Creating and writing into a file
			/*FileOutputStream fout = new FileOutputStream("D:\\akshata.txt");
			String s = "Welcome to Java class.";
			byte b[] = s.getBytes();
			fout.write(b);
			fout.close();
			System.out.println("Success......");*/
			
			
			//Reading from a file
			/*FileInputStream fin=new FileInputStream("D:\\akshata.txt");
			int i=0;
			while((i=fin.read())!=-1)
			{
				System.out.print((char)i);
			}
			fin.close();*/
			
			//File writer
			/*FileWriter fw = new FileWriter("D:\\aksh.txt");
			fw.write("Welcome to SLK. This is Java class.");
			fw.close();*/
			
			//File reader
			FileReader fr = new FileReader("D:\\aksh.txt");
			int i;
			while((i=fr.read())!=-1)
				System.out.print((char)i);
			fr.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		

	}

}
