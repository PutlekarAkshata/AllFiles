package Polymorphism;

public class car extends fourWheeler{
	public String brand;
	
	public car()
	{
		System.out.println("This is car constructor");
	}
	
	public car(String e, String c,int w,String b)
	{
		super(e,c,w);
		brand=b;
		System.out.println("This is car constructor with "+e+" engine, "+c+" color "+w+" Wheels and "+b+" brand");
		
	}

}
