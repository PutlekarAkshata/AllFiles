package Polymorphism;

public class Aleovera extends Plant{
	public String taste;
	
	public Aleovera()
	{
		System.out.println("This is aleovera constructor");
	}
	public Aleovera(int l,String c,String t,String tt)
	{
		super(l,c,t);
		taste=tt;
		System.out.println("this is rose constructor with l,c,t & tt");
	}

}
