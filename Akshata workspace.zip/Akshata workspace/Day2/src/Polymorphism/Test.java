package Polymorphism;

public class Test {

	public static void main(String[] args) {
		LivingThing l=new Plant(1,"aa","bb");
		Plant p=new Rose(2,"qq","ww","ee");
		Plant p1=new Aleovera(2,"qq","ww","ee");

	}

}
