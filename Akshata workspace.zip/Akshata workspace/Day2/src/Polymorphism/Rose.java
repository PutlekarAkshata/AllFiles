package Polymorphism;

public class Rose extends Plant{
	public String fragrance; 
	
	public Rose()
	{
		System.out.println("this is rose constructor");
	}
	
	public Rose(int l,String c,String t,String f)
	{
		super(l,c,t);
		fragrance=f;
		System.out.println("this is rose constructor with l,c,t & f");
	}

}
