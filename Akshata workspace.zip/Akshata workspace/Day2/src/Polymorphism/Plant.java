package Polymorphism;

public class Plant extends LivingThing{
	public String Type;
	
	public Plant()
	{
		System.out.println("This is plant constructor");
	}
	
	public Plant(int l,String c,String t)
	{
		super(l,c);
		Type=t;
		System.out.println("This is Plant constructor with l,c & t");
	}

}
