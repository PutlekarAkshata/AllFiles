package Polymorphism;

public class LivingThing {
	public int lifeSpan;
	public String color;
	
	public LivingThing()
	{
		System.out.println("This is Living thing constructor");
	}
	
	public LivingThing(int l,String c)
	{
		lifeSpan=l;
		color=c;
		System.out.println("This is Living thing constructor with l & c");
	}

}
