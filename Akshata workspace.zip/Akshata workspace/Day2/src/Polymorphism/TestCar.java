package Polymorphism;

public class TestCar {

	public static void main(String[] args) {
		
		fourWheeler f=new car("four Stroke","White",4,"Rolls Royce");

	}

}

 