package Polymorphism;

public class fourWheeler extends Automobile{
	public int wheels;
	
	public fourWheeler()
	{
		System.out.println("This is fourWheeler constructor");
	}
	
	public fourWheeler(String e, String c,int w)
	{
		super(e,c);
		wheels=w;
		System.out.println("This is fourwheeler constructor with "+e+" engine and "+c+" color and "+w+" Wheels");
	}

}
