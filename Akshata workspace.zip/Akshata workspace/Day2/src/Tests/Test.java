package Tests;

import java.util.Scanner;

import allMethods.calculations;

public class Test {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		calculations cal=new calculations();
		
		/*System.out.println("SimpleInterest is "+cal.SimpleInterest());
		//cal.SimpleInterest();
		System.out.println("Area of circle is "+cal.Area());
		//cal.Area();
		cal.Greetings();*/
		
		System.out.println("Enter your choice");
		System.out.println("******************");
		System.out.println("1-- Add two numbers");
		System.out.println("2-- Add two strings and say hello");
		System.out.println("3-- Simple interest");
		System.out.println("4-- Area of circle");
		
		int ch;
		ch=scn.nextInt();
		
		switch(ch)
		{
		case 1: 
			System.out.println("enter value of x");
			int x=scn.nextInt();
			System.out.println("enter value of y");
			int y=scn.nextInt();
			System.out.println(cal.sum(x, y));;
			break;
		case 2: 
			System.out.println("enter first name");
			String fname=scn.next();
			System.out.println("enter last name");
			String lname=scn.next();
			System.out.println("Hello "+cal.greet(fname, lname));
			break;
		case 3: 
			System.out.println("enter principal");
			int p=scn.nextInt();
			System.out.println("enter time");
			int t=scn.nextInt();
			System.out.println("enter rate");
			float r=scn.nextFloat();
			System.out.println("SI= "+cal.simpleInterest(p, r, t));
			
			break;
		case 4:
			System.out.println("Enter radius");
			float rd=scn.nextFloat();
			float PI=3.142f;
			System.out.println("Area "+cal.area(rd, PI));
			
		default:System.out.println("Enter right choice");
		}

	}

}
