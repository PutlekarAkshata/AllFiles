package Inheritance;

public class Rectangle extends Shape {
	public int length;
	public int breadth;
	public String color="blue";
	
	public void calArea()
	{
		System.out.println("area of rectangle is length*breadth");
	}

}
