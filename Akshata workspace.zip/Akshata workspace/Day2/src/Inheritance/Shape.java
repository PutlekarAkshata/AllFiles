package Inheritance;

public class Shape {
	public String color="red";
	public int sides; 
	public String area;
	
	public void calArea()
	{
		System.out.println("This is shape class");
	}
}
