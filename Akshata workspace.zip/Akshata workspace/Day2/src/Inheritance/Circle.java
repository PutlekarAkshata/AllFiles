package Inheritance;

public class Circle extends Shape {
	public int radius;
	
	public void calArea()
	{
		System.out.println("Area of circle is PI*radius*Radius");
	}

}
