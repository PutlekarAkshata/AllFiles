package Inheritance;

public class Test {

	public static void main(String[] args) {
		Shape s=new Shape();
		Rectangle r=new Rectangle();
		Triangle t = new Triangle();
		Circle c=new Circle();
		
		s.calArea();
		System.out.println(r.color);
		 
		r.calArea();
		t.calArea();
		c.calArea();
		

	}

}
