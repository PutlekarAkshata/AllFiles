package Inheritance;

public class Triangle extends Shape {
	public int base;
	public int height;
	
	public void calArea()
	{
		System.out.println("Area of triangle is base * height");
	}
}
