package allMethods;

import java.util.Scanner;

public class calculations {
	Scanner scn=new Scanner(System.in);
	
	
	/*public double SimpleInterest()
	{
		System.out.println("Enter Principal");
		int principal=scn.nextInt();
		System.out.println("Enter Rate of intereest");
		float rate=scn.nextFloat();
		System.out.println("Enter Time");
		int time=scn.nextInt();
		return ((principal*time*rate)/100);
		
	}
	
	public double Area()
	{
		double PI=3.142;
		System.out.println("Enter Radius");
		int radius=scn.nextInt();
		return (PI*radius*radius);
	}
	
	public void Greetings()
	{
		
		System.out.println("Enter name ");
		String name=scn.next();
		System.out.println("Hello "+name);
	}*/
	
	
	public int sum (int x,int y)
	{
		return(x+y);
	}
	
	public String greet(String fname,String lname)
	{
		String g=fname+" "+lname;
		return(g);
	}
	
	public float simpleInterest(int p,float r,int t)
	{
		return((p*t*r)/100);
	}
	
	public float area(float r, float PI)
	{
		return(PI*r*r);
	}

}
