package org.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;



/**
 * Servlet implementation class test
 */
@WebServlet("/test")
public class test extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@Resource(name="jdbc/project")
	private DataSource dataSource;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public test() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Initialize connection object
		PrintWriter out = response.getWriter();
		Connection connect=null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			connect = dataSource.getConnection();
			
			//Create a SQL statement string
		String query="Select * from users";
		stmt = connect.createStatement();
		
		//Execute SQL query
		rs = stmt.executeQuery(query);
		
		//Process result
		while(rs.next())
		{
			out.print("<br/>"+rs.getString("users_id"));
			out.print("<br/>"+rs.getString("username"));
			out.print("<br/>"+rs.getString("email"));
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}*/

}
