package Arrays;

public class Test {

	public static void main(String[] args) {
		CPU c=new CPU();
		c.MotherboardDisplay();
		

	}

}
