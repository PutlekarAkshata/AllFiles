package Arrays;

public class CPU 
{
	private class MotherBoard
	{
		public void display()
		{
			System.out.println("Motherboard has processor, i/p and o/p ports");
		}
	}
	
	public void MotherboardDisplay()
	{
		MotherBoard m=new MotherBoard();
		m.display();
	}

}
