package AbstractInterfaces;

public class car extends fourWheeler{
	public String brand;
	
	public void runs()
	{
		System.out.println("Car runs on 4 wheels");
	}

}
