package AbstractInterfaces;

public class Automobile {
	public String engine;
	public String color;
	
	/*public Automobile()
	{
		System.out.println("This is Automobile constructor");
	}
	
	public Automobile (String e, String c)
	{
		engine=e;
		color=c;
		System.out.println("This is automobile constructor with "+e+" engine and "+c+" color");
	}*/
	
}
