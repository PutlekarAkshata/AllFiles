package AbstractInterfaces;

public class TestCar {

	public static void main(String[] args) {
		
		fourWheeler f=new car();
		f.runs();

	}

}

 