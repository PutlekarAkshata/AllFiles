package AbstractInterfaces;

public abstract class fourWheeler {
	public int wheels;
	
	public abstract void runs(); //only declare bt no implementaion

}
