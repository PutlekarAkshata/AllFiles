package test;

import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		/*int x=10;
		int y=50;
		int z=80;
		if(x>y && y>z)
		{
			System.out.println("X is bigger");
		}
		else if(y>x && y>z)
		{
			System.out.println("Y is bigger");
		}
		else 
		{
			System.out.println("Z is bigger");
		}*/
		
		//int year=1996;
		/*if(year%400==0 ||(year%4==0 && year%100!=0))
		{
			System.out.println("Year is leap");
			
		}
		else
		{
			System.out.println("Year not leap");
		}*/
		
		
		/*int i=0;
		System.out.println("Even numbers");
		for(i=1;i<=10;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
		System.out.println("\nOdd numbers");
		for(i=1;i<=10;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
			}
		}*/
		
		
		//Fibonacci 
		/*int sum,a=0,b=1;
		for(int i=0;i<=10;i++)
		{
			System.out.println(a);
			sum=a+b;
			a=b;
			b=sum;
			
		}*/
		
		/*int i=5;
		System.out.println("Printing i");
		do{
			System.out.println(i);
			i++;
		}while(i<5);
		
		int x=0;
		System.out.println("Printing x");
		while(x<6)
		{
			System.out.println(x);
			x++;
		}*/
		
		
		/*int i=5;
		System.out.println(i);
		System.out.println(++i);
		System.out.println(i++);
		System.out.println(i+3);
		System.out.println(--i);
		System.out.println(i++);*/
		
		int age;
		String name;
		Scanner scn=new Scanner(System.in);
		System.out.println("Enter name");
		name=scn.next();
		System.out.println("enter age");
		age=scn.nextInt();
		System.out.println("name is "+name);
		System.out.println("Age is "+age);
		System.out.println("Enter color");
		String color=scn.next();
		String ch;
		System.out.println("Enter operator");
		
		ch=scn.next();
		/*switch(age)
		{
			case 18:
				System.out.println("you are adult");
				break;
			case 30:
				System.out.println("you are Working professional");
				break;
			case 60:
				System.out.println("you are retired");
				break;
			default:
				System.out.println("Go to himalaya");
		}
		
		switch(color)
		{
			case "Red":
				System.out.println("you are non veg");
				break;
			case "Green":
				System.out.println("you are Veggie");
				break;
			case "Black":
				System.out.println("you are eggiterian");
				break;
			default:
				System.out.println("Go to himalaya");
		}*/
		int x=20,y=10;
		switch(ch)
		{
			case "+":
				System.out.println(x+y);
				break;
			case "-":
				System.out.println(x-y);
				break;
			case "*":
				System.out.println(x*y);
				break;
			case "/":
				System.out.println(x/y);
				break;
			default:
				System.out.println("Invalid operator");
				
		}
	}

}
