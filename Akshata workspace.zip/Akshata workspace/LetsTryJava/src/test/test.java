package test;

import org.dog;
import org.person;

public class test {

	public static void main(String[] args) {
		//Objects of person class
		person x1=new person();
		person x2=new person();
		
		//Objects of dog class
		dog d1=new dog();
		dog d2=new dog();
		
		x1.name="Tom";
		x1.age=22;
		x1.address="Bangalore";
		//x1.display();
		
		x2.name="Akshata";
		x2.age=22;
		x2.address="Hubli";
		//x2.display();
		
		d1.Breed="German Shepherd";
		d1.color="black";
		//d1.eat();
		//d1.sleep();
		
		d2.Breed="Pamorian";
		d2.color="white";
		d2.eat();
		d2.sleep();

	}

}
