package org;

public class person {
	//Attributes of person class
	public String name;
	public int age;
	public String address;
	
	//Methods of person class
	public void display()
	{
		System.out.println("This is person's information");
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		System.out.println("Address: "+address);
		
		System.out.println("Meet "+name+" from "+address+" who is "+age+" years old.");
	}

}
