package org;

public class dog {
	//Attributes
	public String Breed;
	public String color;
	
	//Methods
	public void eat()
	{
		System.out.println(Breed+" of "+color+" eats a lot.");
	}
	
	public void sleep()
	{
		System.out.println(Breed+" of "+color+" color does not sleep at night.");
	}

}
