
public class MyFirstJava {

	public static void main(String[] args) {
		System.out.println("Hello world");
		System.out.println("I am here to learn Java");
		System.out.println("It is Java fundamentals class");
		System.out.println("Hello world");

	}
 
}
