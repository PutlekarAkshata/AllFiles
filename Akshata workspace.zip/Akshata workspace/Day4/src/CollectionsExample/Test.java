package CollectionsExample;

public class Test {

	public static void main(String[] args) {
		Coll c=new Coll();
		c.hash();
		c.queue();

	}

}
