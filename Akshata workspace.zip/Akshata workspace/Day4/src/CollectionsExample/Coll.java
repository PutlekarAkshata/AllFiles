package CollectionsExample;

import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class Coll 
{
	public void hash()
	{
		HashSet<String> hset= new HashSet<String>();
		
		hset.add("Apple");
		hset.add("Mango");
		hset.add("Orange");
		hset.add("Grapes");
		
		hset.add("Apple");
		hset.add("Grapes");
		
		hset.add(null);
		hset.add(null);
		
		System.out.println("******Hash******");
		System.out.println(hset);
	}
	
	public void queue()
	{
		Queue<String> que= new PriorityQueue<String>();
		
		que.add("Akshata");
		que.add("Abhishek");
		que.add("Disha");
		que.add("Madan");
		System.out.println("\n\n");
		System.out.println("******Queue******");
		System.out.println("Head :"+que.element());
		System.out.println("Peek :"+que.peek());
		
		System.out.println("Iterating elements");
		Iterator it=que.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		que.remove();
		que.poll();
		System.out.println("after removing elements");
		Iterator<String> it1=que.iterator();
		while(it1.hasNext())
		{
			System.out.println(it1.next());
		}
	}
}
