
public interface SimpleInterest 
{
	public float CalculateIntersest(int p,int t,float r);

}
