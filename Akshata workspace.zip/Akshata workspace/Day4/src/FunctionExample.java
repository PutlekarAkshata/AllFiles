import java.util.function.*;
public class FunctionExample {
	
	
	static String Show(String name)
	{
		return "Hello "+name;
	}
	
	static void printMsg(String n)
	{
		System.out.println(n+" Hello");
	}
	
	public static void main(String[] args)
	{
		Predicate<Integer> pr = a-> (a>18);
		System.out.println(pr.test(12));
		
		Function<String,String> fun=FunctionExample::Show;
		System.out.println(fun.apply("Akshata"));
		
		Consumer<String> c1=FunctionExample::printMsg;
		c1.accept("Aarthi");
		
		BiFunction<String,String,String> bi=(x,y)->{return x+y;};
		System.out.println(bi.apply("Hello"," Class"));
		
		
	}

}
