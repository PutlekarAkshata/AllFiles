package ExceptionExamples;

public class GenExcp {

	public static void main(String[] args) {
		Gene g= new Gene();
		/*g.method1();
		try {
			g.method2();
		} catch (Exception e) {
			System.out.println("Handling exception");
			
		}*/
		
		//g.method3();
		
		try {
			g.checkAge(15);
		} catch (InvalidAgeException e) {
			
			System.out.println(e);
		}
		

	}

}
