
public class Test {

	public static void main(String[] args) {
		SimpleInterest c= (int p,int t,float r)->((p*t*r)/100);
		System.out.println("Simple Interest= "+c.CalculateIntersest(5000, 4, 6.5f));
	}

}
