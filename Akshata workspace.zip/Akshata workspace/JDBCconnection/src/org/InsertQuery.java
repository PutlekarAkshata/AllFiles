package org;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertQuery {

	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://localhost:3306/hospitalmanagement?useSSL=false";
		String uname="root";
		String pass="1234";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url, uname, pass);
		String query="select max(Id) from person";
		Statement st0=con.createStatement();
		ResultSet rs=st0.executeQuery(query);
		
		int tempId;
		rs.next();
		tempId=rs.getInt(1);
		int P_id=tempId+1;
		String lname="R";
		String fname="AAAA";
		String email="aaa@gmail.com";
		int age=22;
		int gender=2;
		String city="Hubli";
		
		String insertSt="Insert into person values("+P_id+",'"+lname+"','"+fname+"','"+email+"',"+age+","+gender+",'"+city+"')";
		Statement st1=con.createStatement();
		st1.executeUpdate(insertSt);
		System.out.println("Record inserted......");
		con.close();
		

	}

}
