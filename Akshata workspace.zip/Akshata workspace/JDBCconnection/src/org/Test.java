package org;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.cj.api.jdbc.Statement;

public class Test {

	public static void main(String[] args) throws Exception{
		String url = "jdbc:mysql://localhost:3306/hospitalmanagement?useSSL=false";
		String uname="root";
		String pass="1234";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection(url, uname, pass);
		String query="select firstname, age from students";
		Statement st=(Statement) con.createStatement();
		ResultSet rs=st.executeQuery(query);
		while(rs.next())
		{
			String nm=rs.getString("firstname");
			int ag=rs.getInt("age");
			System.out.println(nm);
			System.out.println(ag);
		}
		con.close();

	}

}
