package Org;

public interface Washable {
	
	public void wash();
	
}
