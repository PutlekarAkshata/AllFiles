package Org;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Liquid water=new Liquid();
		Milk tonedMilk = new Milk();
		Coffee latte=new Coffee();
		CoffeeMug mug=new CoffeeMug();
		
		/*mug.addLiquid(water);
		mug.addLiquid(tonedMilk);
		mug.addLiquid(latte);*/
		
		Scanner scn=new Scanner(System.in);
		int ch=scn.nextInt();
		
		System.out.println("Enter what you want 1.Milk 2.Coffee 3.Water ");
		ch=scn.nextInt();
		
		switch(ch)
		{
		case 1: mug.addLiquid(tonedMilk);
				mug.wash(); 
				break;
		case 2: mug.addLiquid(latte);
				break;
		case 3: mug.addLiquid(water);
				break;
		
		}
		
		

	}

}
