package Org;

public class Milk extends Liquid{
	public void swirl()
	{
		System.out.println("Swirling milk");
	}

}
