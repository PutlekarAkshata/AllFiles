package Org;

public class windows implements Washable{
	public void wash()
	{
		System.out.println("Wash windows at Diwali");
		
	}
	

}
