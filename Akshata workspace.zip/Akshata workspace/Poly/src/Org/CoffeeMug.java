package Org;

public class CoffeeMug implements Washable{
	public void addLiquid(Liquid li)
	{
		li.swirl();
	}
	
	public void wash()
	{
		System.out.println("You wash coffee mug");
	}

}
