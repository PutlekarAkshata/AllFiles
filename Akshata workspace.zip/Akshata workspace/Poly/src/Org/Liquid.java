package Org;

public class Liquid {
	public void swirl()
	{
		System.out.println("Swirling liquid");
	}

}
