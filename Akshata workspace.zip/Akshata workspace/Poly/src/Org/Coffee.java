package Org;

public class Coffee extends Liquid{
	public void swirl()
	{
		System.out.println("Swirling Coffee");
	}
}
